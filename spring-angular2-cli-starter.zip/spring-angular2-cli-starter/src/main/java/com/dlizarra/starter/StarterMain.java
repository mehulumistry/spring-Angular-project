package com.dlizarra.starter;

public class StarterMain {

	public static void main(final String... args) {
		new StarterApplication(AppConfig.class).run(args);
	}

}
