package com.dlizarra.starter.role;

public enum RoleName {
	ROLE_ADMIN, ROLE_USER
}
