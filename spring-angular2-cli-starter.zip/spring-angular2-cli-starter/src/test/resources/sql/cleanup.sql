delete from "role";
delete from "users";

